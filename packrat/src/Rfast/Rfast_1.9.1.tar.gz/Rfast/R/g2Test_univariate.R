
g2Test_univariate <- function(data,dc) {
    .Call(Rfast_g2Test_univariate,data,dc)
}