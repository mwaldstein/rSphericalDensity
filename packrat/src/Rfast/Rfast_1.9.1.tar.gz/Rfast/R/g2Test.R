
g2Test <- function(data,x,y,cs,dc) {
    .Call(Rfast_g2Test,data,x,y,cs,dc)
}