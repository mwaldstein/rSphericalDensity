
floyd<-function(x){
  i4_huge<-2147483647
  y<-as.vector(x)
  y[is.na(y)]<-i4_huge
  dm<-dim(x)[2L]
  y<-.Call(Rfast_floyd_john,dm,y)
  y[y==i4_huge]<-NA
  y[seq.int(1,length(y),dim(x)[2L]+1)]<-0
  dim(y)<-c(dm,dm)
  y
}