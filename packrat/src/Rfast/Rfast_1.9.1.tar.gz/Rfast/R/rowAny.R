

rowAny <- function(x) {
  .Call(Rfast_row_any,x)
}