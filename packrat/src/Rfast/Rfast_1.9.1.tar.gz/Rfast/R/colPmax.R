
colPmax <- function(x,y) {
  .Call(Rfast_col_pmax,x,y)
}