
rowTrue <- function(x) {
  .Call(Rfast_row_true,x)
}