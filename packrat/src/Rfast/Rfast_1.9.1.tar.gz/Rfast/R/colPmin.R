
colPmin <- function(x,y) {
  .Call(Rfast_col_pmin,x,y)
}