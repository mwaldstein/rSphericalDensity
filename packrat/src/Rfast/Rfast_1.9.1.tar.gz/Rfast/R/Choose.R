
Choose <- function(x,k) {
  .Call(Rfast_Choose,x,k)
}