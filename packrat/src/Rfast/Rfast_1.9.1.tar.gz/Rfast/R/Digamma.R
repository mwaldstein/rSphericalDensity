
Digamma <- function(x) {
  .Call(Rfast_Digamma,x)
}