
Trigamma <- function(x) {
  .Call(Rfast_Trigamma,x)
}