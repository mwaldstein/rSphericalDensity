
colFalse <- function(x) {
  .Call(Rfast_col_false,x)
}