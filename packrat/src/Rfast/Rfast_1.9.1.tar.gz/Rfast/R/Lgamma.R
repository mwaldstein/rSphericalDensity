
Lgamma <- function(x) {
  .Call(Rfast_Lgamma,x)
}