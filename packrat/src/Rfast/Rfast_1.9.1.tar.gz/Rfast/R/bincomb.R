

bincomb <- function(n) {
  .Call(Rfast_bincomb,n)
}