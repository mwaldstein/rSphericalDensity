

mat.mat <- function(x, y) {
	.Call(Rfast_mat_mat,x,y)
}