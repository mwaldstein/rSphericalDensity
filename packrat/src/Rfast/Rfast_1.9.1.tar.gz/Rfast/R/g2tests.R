
g2tests <- function(data,x,y,dc) {
    .Call(Rfast_g2tests,data,x,y,dc)
}