
rbing <- function(n,lam) {
	.Call(Rfast_rbing,n,lam)
}