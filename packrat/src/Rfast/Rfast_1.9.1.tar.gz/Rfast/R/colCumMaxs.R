
colCumMaxs <- function(x) {
	.Call(Rfast_col_cum_maxs,x)
}