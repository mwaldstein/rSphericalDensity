
Lchoose <- function(x,k) {
  .Call(Rfast_Lchoose,x,k)
}