
which_isFactor <- function(x) {
  .Call(Rfast_which_isFactor,x)
}