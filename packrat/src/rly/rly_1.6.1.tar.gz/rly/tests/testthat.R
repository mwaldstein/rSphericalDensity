#! /usr/bin/env Rscript

library(testthat)
library(rly)

test_check("rly")