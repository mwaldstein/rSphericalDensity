iag.mle <- function(y, tol = 1e-07) {
  Rfast::iag.mle(y, tol = tol)
}
