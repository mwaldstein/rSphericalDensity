library(testthat)
library(pds3)

test_check("pds3")
